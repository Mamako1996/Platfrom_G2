<template>
  <div>
    <h1 class="title">
      Welcome to High-Throughput Material Composition Project
    </h1>
    <figure>
        <img src="/SmartLabImg.png" style="width: 40%;">
    </figure>
    <br>
    <div class="field">
      <p>
        This is a project presented by MuCSL x HKUST 
        under the supervision of Prof. Jinglei YANG 
        and prof. Molong DUAN.
      </p>
      <p>
        Major team member include Guoxiong David MA, Zeonjin Justin Yip and Haozhe Eric CUI.
      </p>
    </div>
  </div>
</template>
