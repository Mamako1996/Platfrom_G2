# Developer Notes

This is a developer note that serves as an record of waht has been done and why.

2024-03-20

It felt like that the HTTP is actually not needed. As if the MQTT goes down, then everything will die. So I will just remove the HTTP feature I think. By removing the HTTP, I could also remove the NVS.

